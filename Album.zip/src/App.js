import React, { Component, lazy, Suspense } from 'react';
import './App.css';
// import { css } from '@emotion/core';
import { ClipLoader } from 'react-spinners';
import AlbumList from './component/album';
// const AlbumList =lazy(()=>import('./component/album'));


class App extends Component {
  constructor(){
    super();
    this.state={
      title:"Album List",
      albumListData:[],
      albumDataImage:[],
      loading: true,
      resLength:'',
      error:''

    }
    this.fetchAlbumList=this.fetchAlbumList.bind(this);
  }

  async fetchAlbumList(){ 
  try{   
    var dataArray=[]
    const url='https://jsonplaceholder.typicode.com/albums';
    var response = await fetch(url,{
      method:'GET',
      body:JSON.stringify()
    });

    response= await response.json();

        for(var i=0;i<response.length;i++){

          var id=response[i]['id'];
          var user_id= response[i]['userId']
          var title= response[i]['title']
          var url_image='https://jsonplaceholder.typicode.com/photos?albumId='+id;

          var albumData = await fetch(url_image,{
            method:'GET',
            body:JSON.stringify()
          });

          albumData= await albumData.json();

          var albumDataObject = {
            "user_id":user_id,
            "title":title,
            "album_id":id,
            "album_data":albumData
          }
          dataArray.push(albumDataObject);          
        }
        
        this.setState({loading:false});

      this.setState({albumDataImage:dataArray}); 
      } catch(err){
          this.setState({
            error:{
              errorMsg:"Data Not Found ",
              errorResult:err
            }
          });
      }   
  }


  componentDidMount(){
    this.fetchAlbumList(); 
  }

  render() {
    return (
      <div className="App"> 
          <h1>{this.state.error}</h1>
          <main>
            
            <section>
              <div className='sweet-loading'>
              <ClipLoader                
                sizeUnit={"px"}
                size={150}
                color={'#123abc'}
                loading={this.state.loading}
              />
            </div>
            
              {                
                this.state.albumDataImage.map((mydata,i) => 
                    <AlbumList data={mydata} key={i}/>                  
                )
              }
            
            </section>
          </main>
      </div>
    );
  }
}

export default App;
