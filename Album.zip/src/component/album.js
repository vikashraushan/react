import React from 'react';
import ReactSimpleCarousel from "react-spring-carousel";
import LazyLoad from 'react-lazyload';

 const album=(props)=>{ 	
 	const Styles={
 		headerStyle:{
 			backgroundColor: '#9cf4f4',
		    padding:'10px 20px',
		    textAlign: 'left',
		    margin: '20px 20px 0px 20px'
 		},

 		albumStyle:{
 			backgroundColor: '#d1fdfd',
		    margin: '0px 20px 20px 20px',
		    padding: 10,
		    textAlign: 'left',
		    height: 'auto'
 		},
 		imgStyle:{
 			margin:5 		
 		},
 		imgMarginBottom:{
 			marginBottom: 10
 		},
 		pStyle:{
 			clear: 'both',
 			margin:0
 		}
 	}

 	
 	return(
 			<div>
 				<header style={Styles.headerStyle}>
 					<span style={{fontSize:14, float:'left', fontWeight:'bold'}}>Album Title: </span> 
 					<h4 style={{textTransform: 'capitalize',float:'left',margin: '-15px 0 0 10px'}}>{props.data.title}</h4>
					<p style={Styles.pStyle}>User Id: {props.data.user_id} </p>
					<p style={Styles.pStyle}>Album Id: {props.data.album_id}</p>					
				</header>
				<section style={Styles.albumStyle} key={props.data.album_id}>
				<LazyLoad>
				<ReactSimpleCarousel slidesToShow={5}>
				{
					props.data.album_data.map((dataAlbum,i)=>						
						<div key={i} className="App-slide">
			              <img src={dataAlbum.thumbnailUrl} alt="" style={Styles.imgMarginBottom}/>
			              <p>{dataAlbum.title} </p>
			              <p>Id: {dataAlbum.id} </p>
			          </div>			          
					)
				}
				</ReactSimpleCarousel>
				</LazyLoad>
				</section> 							
 			</div>
 			
 		)
 }

 export default album;
