import React, {Component} from 'react';
import jsPDF from 'jspdf';

const MyStyle={
		MyStyle_jumbotron:{
			padding:10,
			margin:10
		},
		MyStyle_borderbottom:{
			borderBottom: 'solid thin #ccc'
		},
		small:{
		    fontSize: '100%'
		}
	}

const MyStyle1={
		MyStyle_jumbotron1:{
			textAlign:'center'
		}
	}

class Resume extends Component{	

  printDocument() {
    const input = document.getElementById('divToPrint');
        const pdf = new jsPDF();
		pdf.fromHTML(input, 10,1)
        pdf.save("shail.pdf");
  }
  
  	render(){		
		return(
			<main>
			<div className="mb5">
				<button onClick={this.printDocument}>PDF</button>
			  </div>
			<div id="divToPrint">
				<section>
				 
				    <h3 style={MyStyle1.MyStyle_jumbotron1}>Vikash Rawshan</h3>
				    <h4 className="text-primary" style={{textAlign:'center'}}>Frontend Developer</h4>				    
				  
				  <div className="panel panel-default">
				  		<div className="panel-body">
				  			<div className="container">
				  				<div className="row">
						  			<p>A versatile professional with excellence in strengthening companies to lead in highly competitive situations in IT/ Software.</p>
						  			<h5>Targeting assignments in Project Management, Software/Application Development - PHP Applications</h5>
				  				</div>
				  			</div>
				  			<div className="container">
				  				<div className="row">
								    <div className="col-sm-4">
								    	<h5 className="text-primary" style={MyStyle.MyStyle_borderbottom}>PERSONAL DETAILS</h5> 
								  		<ul>
								  			<li><h5>Date of Birth: <small style={MyStyle.small}>02nd Feb 1987</small></h5></li>
								  			<li><h5>Languages Known: <small style={MyStyle.small}>English & Hindi (Speak)</small></h5></li>
								  			<li><h5>Address: <small style={MyStyle.small}>24, Saptgri Layout, Marathali, Benglore</small></h5></li>
								  			<li><h5>Phone: <small style={MyStyle.small}>+91-9891377959</small></h5></li>
								  			<li><h5>E-Mail: <small style={MyStyle.small}>vikashraushan87@gmail.com</small></h5></li>
								  			<li><h5>Skype: <small style={MyStyle.small}>vikash_jsr2</small></h5></li>
								  		</ul>

								  		<h5 className="text-primary" style={MyStyle.MyStyle_borderbottom}>EDUCATION</h5> 
								  		<ul>
								  			<li><h5>BCA from IGNOU, Jamshedpur location in 2012</h5></li>
								  			<li><h5>Pursuing MCA from IGNOU, Noida</h5></li>
								  		</ul>

								  		<h5 className="text-primary" style={MyStyle.MyStyle_borderbottom}>TECHNICAL SKILLS</h5> 
								  		<ul className="list-unstyled">
								  			<li><h5>Languages known: <small style={MyStyle.small}>HTML,CSS,JAVASCRIPT,JQUERY</small></h5></li>
								  			<li><h5>Domain Knowledge: <small style={MyStyle.small}>HTML5, CSS3, Javascript, Jquery, Jquery Mobile, REST API, JSON, Third-party API, Payment Integration, MYSQL, Apache, Linux, REACTJS , NODEJS</small></h5></li>
								  			<li><h5>Operating System: <small style={MyStyle.small}>  Linux(Ubuntu, CentOS), Windows XP, Windows 7/Vista, Windows 8, Windows 10</small></h5></li>
								  			<li><h5>Knowledge in IDE: <small style={MyStyle.small}>  Sublime, Notepad++, Dreamweaver</small></h5></li>
								  			<li><h5>Application Knowledge: <small style={MyStyle.small}>Photoshop CS5</small></h5></li>
								  		</ul>
								    </div>
								    <div className="col-sm-8">
								    	<div className="jumbotron" style={MyStyle.MyStyle_jumbotron}>
										    <h5 className="text-primary" style={MyStyle.MyStyle_borderbottom}>PROFILE SUMMARY</h5> 
										    <ul>
									  			<li><h5>Highly motivated, energetic & achievement oriented professional with 3+ years’ experience in php & mobile applications</h5></li>
									  			<li><h5>Currently associated with Zing Mobile Technologies, Noida (UP) as Software Engineer – Php Developer.</h5></li>
									  			<li><h5>Strong knowledge of HTML/HTML5, CSS/CSS3, JavaScript, JQuery, Core-PHP, Codeigniter, REACTJS, NODEJS (Basic), MVC, MySQL, API (REST), JSON, OOPS and so on.</h5></li>
									  			<li><h5>Hands-on experience in designing highly usable web & mobile applications (API).</h5></li>
									  			<li><h5>Exposure in implementing and managing designing of user interfaces for products that not only facilitate development & design efforts but also make the product truly user-friendly to customer</h5></li>
									  			<li><h5>High integrity & energetic person with proven skills in quality assurance and product development to deliver quality services to clients / customers</h5></li>
									  		</ul> 
										</div>
										<div>
											<h5 className="text-primary" style={MyStyle.MyStyle_borderbottom}>WORK EXPERIENCE</h5> 
										    <ul>
									  			<li><h5>Current Employer(Since March 2014 to Till Date)
												Zing Mobile Technologies, Noida (UP) as Senior Software Engineer - PHP Developer
												</h5></li>
									  			<li><h5>Past(Feb 2012 - March 2014)
												Anmoul Infotech Pvt. Ltd., Jamshedpur, as Web Developer/Designer (PHP).
												</h5></li>
									  		</ul>

									  		<h5 className="text-primary" style={MyStyle.MyStyle_borderbottom}>Key Result Areas</h5> 
										    <ul>
									  			<li>Developing and documenting detailed user experience deliverables including requirements docs, journeys, interaction flows, story boards, wireframes, prototypes, functional specifications, and fully realized page, site and product designs</li>
									  			<li>Maintaining high design standards; understanding the target audiences’ needs, tasks, and goals and translating them into creative concepts</li>
									  			<li>Functioning directly with developers and testers to make what’s designed happen in code; writing and exemplifying brand and usage guidelines; enhancing images and formatting text</li>
									  			<li>Describing new approaches for complex design problems; designing print and marketing initiatives for all website properties and events</li>
									  		</ul>
										</div>
								    </div>
								    <div className="col-sm-12">
								    	<div className="jumbotron" style={MyStyle.MyStyle_jumbotron}>
										    <h5 className="text-primary" style={MyStyle.MyStyle_borderbottom}>PROJECTS COMPLETED</h5> 
										    <ul className="list-unstyled">
									  			<li><h5>Project Name: ACM3 (Ads Campaign Management)</h5></li>
												<li><h5>Technologies : REACTJS,JAVASCRIPT,JQUERY, MYSQL, NODEJS</h5></li>
												<li><h5>Category: Ads Platforms</h5></li>
												<li><h5>Description: ACM application is used to regulate advertising that in the online media to publish the Advertising network will redirect to our ACM Platform and process the msisdn to the telco and shows the content page for the  web and wap campaigns</h5></li>
												<li><h5>Team Size: 7</h5></li>
												<li><h5>Duration: Oct 2018 to Till Now.</h5></li>
									  		</ul> 
										</div>

										<div style={MyStyle.MyStyle_jumbotron}>
										    <ul className="list-unstyled">
									  			<li><h5>Project Name: ACM2</h5></li>
												<li><h5>Technologies : REACTJS, PHP, JAVASCRIPT, JQUERY, MYSQL</h5></li>
												<li><h5>Category: Ads Platforms</h5></li>
												<li><h5>Description: ACM application is used to regulate advertising that in the online media to publish the Advertising network will redirect to our ACM Platform and process the msisdn to the telco and shows the content page for the  web and wap campaigns</h5></li>
												<li><h5>Team Size: 11</h5></li>
												<li><h5>Duration: July 2017 to Till Now.</h5></li>
									  		</ul> 
										</div>

										<div className="jumbotron" style={MyStyle.MyStyle_jumbotron}>
										    <ul className="list-unstyled">
									  			<li><h5>Project Name: Focus Point</h5></li>
												<li><h5>Technologies : PHP,JAVASCRIPT,JQUERY, MYSQL</h5></li>
												<li><h5>Category: Application</h5></li>
												<li><h5>Description: It is a free Application developed, you can search the latest edition brands and purchase new eyewear at your fingertips. It is a free Application developed you can search the latest edition brands and purchase new eyewear at your fingertips .It is a free Application developed you can search the latest edition brands and purchase new eyewear at your fingertips</h5></li>
												<li><h5>Team Size: 3</h5></li>
												<li><h5>Duration: Nov 2015 to Till Now</h5></li>
									  		</ul> 
										</div>										
								    </div>
							  	</div>
							</div>
				  		</div>
				  </div>
				</section>
				</div>
			</main>
		)
	}
}
export default Resume;
