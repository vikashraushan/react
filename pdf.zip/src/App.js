import React, { Component } from 'react';
import { Document, Page } from 'react-pdf';
import Resume from './Resume';

class App extends Component {
  render() {    
    return (
      <div className="App">            
            <Resume/>
      </div>
    );
  }
}

export default App;
